const destinations = [
  { name: "الهند", flag: "🇮🇳", image: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=900&q=80" },
  { name: "الصين", flag: "🇨🇳", image: "https://images.unsplash.com/photo-1536599011-8b9b9d3b5d7f?auto=format&fit=crop&w=900&q=80" },
  { name: "تركيا", flag: "🇹🇷", image: "https://images.unsplash.com/photo-1527838832700-5059252407fa?auto=format&fit=crop&w=900&q=80" },
  { name: "ماليزيا", flag: "🇲🇾", image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=80" },
  { name: "رواندا", flag: "🇷🇼", image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80" },
  { name: "أوغندا", flag: "🇺🇬", image: "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=900&q=80" },
  { name: "روسيا", flag: "🇷🇺", image: "https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=900&q=80" },
  { name: "إثيوبيا", flag: "🇪🇹", image: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80" },
  { name: "تنزانيا", flag: "🇹🇿", image: "https://images.unsplash.com/photo-1527631746610-bca00a040d60?auto=format&fit=crop&w=900&q=80" },
  { name: "المالديف", flag: "🇲🇻", image: "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=900&q=80" },
  { name: "تايلاند", flag: "🇹🇭", image: "https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=900&q=80" },
  { name: "إندونيسيا", flag: "🇮🇩", image: "https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=900&q=80" },
  { name: "سيشل", flag: "🇸🇨", image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80" },
  { name: "موريشيوس", flag: "🇲🇺", image: "https://images.unsplash.com/photo-1493558103817-58b2924b5713?auto=format&fit=crop&w=900&q=80" },
  { name: "الإمارات", flag: "🇦🇪", image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=80" },
  { name: "المملكة العربية السعودية", flag: "🇸🇦", image: "https://images.unsplash.com/photo-1521295121783-8a321d551ad2?auto=format&fit=crop&w=900&q=80" },
];

const GOOGLE_FORM_URL = "https://forms.gle/REPLACE_WITH_YOUR_GOOGLE_FORM_LINK";
const GOOGLE_FORM_FIELD_IDS = {
  name: "entry.1234567890",
  phone: "entry.0987654321",
  service: "entry.1122334455",
  destination: "entry.5566778899",
  travellers: "entry.9988776655",
  date: "entry.6677889900",
  notes: "entry.3344556677",
};

function buildGoogleFormUrl(data) {
  if (!GOOGLE_FORM_URL || GOOGLE_FORM_URL.includes("REPLACE_WITH_YOUR_GOOGLE_FORM_LINK")) {
    return "";
  }

  const params = new URLSearchParams();
  params.set(GOOGLE_FORM_FIELD_IDS.name, data.name || "");
  params.set(GOOGLE_FORM_FIELD_IDS.phone, data.phone || "");
  params.set(GOOGLE_FORM_FIELD_IDS.service, data.service || "");
  params.set(GOOGLE_FORM_FIELD_IDS.destination, data.destination || "");
  params.set(GOOGLE_FORM_FIELD_IDS.travellers, String(data.travellers || ""));
  params.set(GOOGLE_FORM_FIELD_IDS.date, data.date || "");
  params.set(GOOGLE_FORM_FIELD_IDS.notes, data.details || "");

  return `${GOOGLE_FORM_URL}?usp=pp_url&${params.toString()}`;
}

document.addEventListener("DOMContentLoaded", () => {
  const countryGrid = document.getElementById("countryGrid");

  if (countryGrid) {
    countryGrid.innerHTML = destinations
      .map(
        (country) => `
          <div class="destination-item" style="background-image: linear-gradient(180deg, rgba(7, 30, 51, 0.0), rgba(7, 30, 51, 0.75)), url('${country.image}');">
            <span>${country.flag} ${country.name}</span>
          </div>
        `
      )
      .join("");
  }

  const year = document.getElementById("year");
  if (year) {
    year.textContent = new Date().getFullYear();
  }

  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const form = document.querySelector(".booking-form");
  const formMessage = document.querySelector(".form-message");

  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const name = formData.get("name") || "العميل";
      const phone = formData.get("phone") || "";
      const service = formData.get("service") || "خدمة السفر";
      const destination = formData.get("destination") || "غير محدد";
      const travellers = formData.get("travellers") || "1";
      const date = formData.get("date") || "غير محدد";
      const details = formData.get("details") || "لا توجد ملاحظات إضافية";

      const whatsappText = [
        "مرحباً فريق ترافيا، أود طلب خدمة جديدة.",
        `الاسم: ${name}`,
        `الهاتف: ${phone}`,
        `نوع الخدمة: ${service}`,
        `الوجهة: ${destination}`,
        `عدد المسافرين: ${travellers}`,
        `تاريخ السفر: ${date}`,
        `ملاحظات: ${details}`,
      ].join("\n");

      const emailSubject = encodeURIComponent(`طلب حجز جديد - ${service}`);
      const emailBody = encodeURIComponent([
        "مرحباً فريق ترافيا،",
        "",
        "أرغب في حجز خدمة جديدة.",
        `الاسم: ${name}`,
        `الهاتف: ${phone}`,
        `نوع الخدمة: ${service}`,
        `الوجهة: ${destination}`,
        `عدد المسافرين: ${travellers}`,
        `تاريخ السفر: ${date}`,
        `ملاحظات: ${details}`,
        "",
        "شكراً لكم."
      ].join("\n"));

      const whatsappUrl = `https://wa.me/249127454000?text=${encodeURIComponent(whatsappText)}`;
      const emailUrl = `mailto:info@trafiya-travel.com?subject=${emailSubject}&body=${emailBody}`;
      const googleFormUrl = buildGoogleFormUrl({
        name,
        phone,
        service,
        destination,
        travellers,
        date,
        details,
      });

      if (formMessage) {
        formMessage.textContent = `شكرًا ${name}، تم تجهيز طلبك بنجاح. تم فتح واتساب، البريد الإلكتروني، ونموذج Google Form لتأكيد الحجز.`;
        formMessage.classList.add("visible");
      }

      if (googleFormUrl) {
        window.open(googleFormUrl, "_blank", "noopener,noreferrer");
      }

      window.open(whatsappUrl, "_blank", "noopener,noreferrer");
      window.location.href = emailUrl;
      form.reset();
    });
  }
});
